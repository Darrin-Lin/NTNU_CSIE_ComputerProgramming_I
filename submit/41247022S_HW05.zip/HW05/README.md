hw05
===

### 41247022S 林德恩

---

## How to build my code
在 HW05 directory 下 make 指令。

---

## log

---

### hw0501

#### 12/1 Finish
快速的把第一題寫好了，還沒測。

----

### hw0502

#### 12/1 Finish
不知道當無解或多組解要把 vector x 怎麼處理，所以寫信去問，也不確定 calloc 可不可以用，所以先寫好了，等回信再改。
助教回信了說 多組解把 pointer 設為 NULL
然後又在計算過程中用 double 避免誤差擴大。

#### 12/4 Debug
把 NULL 化後忘了 free 補上。

----

### hw0503

#### 12/1 Finish
no such a plane 不知道跟 inputs are invalid 有什麼差別，所以之後再改。

#### 12/3 Update
助教回信了，說需要在回傳時四捨五入到小數點第二位。

----

### hw0504

#### 12/2 Finish
不確定 skip 會有 value 跟 length 以及 length 計算方式還有 print 格式。

----

### hw0505

#### 12/2 Finish
不知道 decode.c 要怎麼用，先寫完其他部分並寫信問助教了。

####　12/3 Update
助教回信了，說 decode.c 只要在 Makefile 連結就好，~~然後 free 那邊有問題~~ realloc 會自動釋放。

----

### hw0506

#### 12/1 Finish
寫完了。