#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#pragma once

int32_t statistics ( int32_t *pData , int32_t size , double *pMean, double *pVariance , double *pStd );