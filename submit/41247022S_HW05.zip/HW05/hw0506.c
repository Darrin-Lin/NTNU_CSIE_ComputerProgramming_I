#include <stdio.h>
#include <stdint.h>

int main()
{
    // int16_t arr[6] = {0};
    // for (int32_t i = 5; i > 0; i--)
    // {
    //     scanf("%d", &arr[i - 1]);
    //     for (int32_t j = 0; j < 5; j++)
    //     {
    //         printf("%hd ", arr[j]);
    //     }
    //     printf("\n");
    // }
    // for (int32_t j = 0; j < 5; j++)
    // {
    //     printf("%d ", arr[j]);
    // }
    return 0;
}