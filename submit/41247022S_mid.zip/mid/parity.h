#include <stdint.h>
#include <stdio.h>
#pragma once

uint64_t parity_2d( int32_t , int32_t , int32_t , int32_t , int32_t );