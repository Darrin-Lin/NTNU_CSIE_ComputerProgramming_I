#include <stdio.h>
#include <stdint.h>

int main()
{

    return 0;
}