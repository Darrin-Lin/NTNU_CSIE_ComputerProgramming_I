mid
===

### 41247022S 林德恩

---

## How to build my code
在 mid directory 下 make 指令。

---

