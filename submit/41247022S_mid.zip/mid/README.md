mid
===

### 41247022S 林德恩

---

## How to build my code
在 mid directory 下 make 指令。

---

# [mid06](./bonus.txt) 
mid06 寫在 bonus.txt 裡面。