#include <math.h>
#include <stdint.h>

#pragma once

void setup_girl_weight( uint32_t );
void setup_boy_weight( uint32_t );
int64_t afford_weight( int32_t x, int32_t y );