#include <stdio.h>
#include <stdint.h>
#include "mine.h"
int main()
{

    return 0;
}