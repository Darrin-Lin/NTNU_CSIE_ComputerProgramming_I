#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <stdint.h>

#pragma once

void the_hanoi_tower(int32_t disk_number);