#include <stdlib.h>
#include <math.h>
#include <stdint.h>
#include <time.h>

#pragma once

int32_t dice(int32_t);
void Id6();
void AdX();
void AdXkY_add_B();
void AdXkhHklLkcC_add_B();